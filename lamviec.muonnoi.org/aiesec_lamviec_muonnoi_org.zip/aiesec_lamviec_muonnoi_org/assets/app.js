(function(){
  const ACCESS_KEY = "CHANGE_THIS_KEY"; // Team dev: thay bằng key thật hoặc inject từ env/build step.
  const STORAGE_KEY = "aiesec_lamviec_access_v1";
  const SUBMIT_ENDPOINT = ""; // Optional: ví dụ /api/aiesec-access để lưu lead vào D1/Sheet/CRM.
  function qs(s){return document.querySelector(s)}
  function hasAccess(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||"{}").ok===true}catch(e){return false}}
  function openGate(){const gate=qs('#accessGate'); if(gate && !hasAccess()) gate.classList.add('active')}
  function unlock(payload){localStorage.setItem(STORAGE_KEY,JSON.stringify({ok:true,at:new Date().toISOString(),payload})); const gate=qs('#accessGate'); if(gate) gate.classList.remove('active')}
  async function submitLead(payload){
    if(!SUBMIT_ENDPOINT) return;
    try{await fetch(SUBMIT_ENDPOINT,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(payload)})}catch(e){console.warn('Lead submit failed',e)}
  }
  window.addEventListener('DOMContentLoaded',()=>{
    openGate();
    const form=qs('#accessForm'); if(!form) return;
    form.addEventListener('submit',async(e)=>{
      e.preventDefault();
      const data=Object.fromEntries(new FormData(form).entries());
      const required=['accessKey','fullName','phone','email'];
      const missing=required.filter(k=>!String(data[k]||'').trim());
      const err=qs('#gateError');
      if(missing.length){if(err){err.textContent='Vui lòng nhập đầy đủ Key, họ tên, số điện thoại và email.';err.style.display='block'};return}
      if(String(data.accessKey).trim()!==ACCESS_KEY){if(err){err.textContent='Key chưa đúng. Vui lòng kiểm tra lại.';err.style.display='block'};return}
      const payload={fullName:data.fullName,phone:data.phone,email:data.email,organization:data.organization||'',source:location.pathname,at:new Date().toISOString()};
      await submitLead(payload); unlock(payload);
    })
  })
})();
