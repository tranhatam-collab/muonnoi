# NGUOIVIET_MUONNOI_DSTS_FLAGSHIP_PROGRAM_ARCHITECTURE_2026

**Ngày:** 2026-06-12  
**Trạng thái:** Founder Review Draft  
**Phạm vi:** `duongsaotoasang.com` trong quan hệ với `nguoiviet.muonnoi.org`  
**Mục đích:** Khóa vai trò của Đường Sao Tỏa Sáng (DSTS) như flagship program đầu tiên của Người Việt Muôn Nơi.

---

## I. PHÁN QUYẾT CHIẾN LƯỢC

### 1.1. Kết luận

`duongsaotoasang.com` **không nên** đứng như:

- một dự án lẻ tách rời umbrella mission
- một site “self-help” / truyền cảm hứng chung chung
- một website gọi vốn public
- một blog cá nhân không có program structure

`duongsaotoasang.com` **nên** đứng như:

> **Flagship Transformation Program**  
> Chương trình trọng điểm của Người Việt Muôn Nơi, nơi người tham gia đi qua hành trình học, trải nghiệm, thực hành, chứng minh tiến bộ, và kết nối vào hệ cơ hội lớn hơn.

### 1.2. Vì sao chọn DSTS làm flagship

DSTS mạnh vì:

- dễ kể chuyện
- dễ xây journey
- dễ đóng gói cohort / track / fellowship
- dễ tạo case study
- dễ gắn mentor
- dễ nhận donor / sponsor support theo suất / cohort / chapter
- dễ chứng minh impact hơn các platform lớn và trừu tượng

**Kết luận:**  
Muốn Người Việt Muôn Nơi có đẳng cấp, cần một chương trình flagship thật mạnh. DSTS là ứng viên phù hợp nhất để làm chương trình “mặt tiền” tạo trust và impact.

---

## II. VAI TRÒ CỦA DSTS TRONG HỆ

### 2.1. Vị trí đúng

| Thành phần | Vai trò |
|-----------|---------|
| `nguoiviet.muonnoi.org` | Umbrella mission / governance / network |
| `duongsaotoasang.com` | Flagship program / story brand / measurable impact |
| Các platform khác | Workforce / learning / housing / AI / career / partner lanes |

### 2.2. DSTS phải tạo ra điều gì

DSTS không được dừng ở “truyền cảm hứng”.  
DSTS phải tạo ra 5 loại đầu ra:

1. **Participant journey** — người tham gia đi từ nhận thức → kỷ luật → thực hành → tiến bộ
2. **Case studies** — câu chuyện thật, có before/after hợp lý
3. **Mentor engine** — người dẫn đường và người đồng hành
4. **Scholarship / sponsored seats** — nơi donor thấy tiền đi vào tác động cụ thể
5. **Progression lane** — người tham gia có thể đi tiếp sang học tập, việc làm, community leadership, hoặc chương trình khác

---

## III. DSTS NÊN LÀ CHƯƠNG TRÌNH GÌ?

### 3.1. Khung định nghĩa đúng

DSTS là:

- chương trình phát triển cá nhân và cộng đồng
- chương trình định hướng năng lực và hành động
- chương trình trải nghiệm / học / làm / đồng hành
- chương trình có mentor, cohort, milestone và review
- chương trình không hứa đổi đời nhanh
- chương trình không bán ảo tưởng thành công

### 3.2. DSTS không được là gì

- không phải cult / phong trào cảm xúc
- không phải seminar truyền động lực
- không phải khóa học “làm giàu”
- không phải cơ chế nhận tiền công khai để chia lợi nhuận
- không phải quỹ đầu tư trá hình

---

## IV. ARCHITECTURE CỦA CHƯƠNG TRÌNH

### 4.1. 5 lớp chuẩn

#### Lớp 1 — Public Narrative
- chương trình là gì
- dành cho ai
- vì sao tồn tại
- hành trình gồm những gì
- kết quả mong đợi thực tế
- ai không phù hợp

#### Lớp 2 — Program Structure
- track / cohort / chapter
- duration
- format
- milestones
- mentor touchpoints
- apply & selection logic

#### Lớp 3 — Participant Operations
- registration
- onboarding
- attendance / participation
- weekly review
- progress logging
- support / escalation

#### Lớp 4 — Impact Reporting
- participant counts
- cohort completion
- sponsored seats
- story approvals
- impact log
- donor-facing updates

#### Lớp 5 — Governance & Safeguards
- code of conduct
- privacy / consent
- story permission
- child / youth safeguards nếu có
- refund / scholarship / sponsor rules
- grievance / contact process

---

## V. JOURNEY ĐỀ XUẤT

### 5.1. Public journey

1. Hiểu DSTS là gì
2. Chọn track phù hợp
3. Apply / nominate / sponsor
4. Được review
5. Onboarding
6. Tham gia chương trình
7. Có milestone + reflection
8. Kết thúc cohort / journey
9. Đi tiếp sang lane khác trong hệ

### 5.2. Các track nên cân nhắc

#### Track A — Explorers
Dành cho người mới, tìm lại hướng đi, cần bắt đầu lại

#### Track B — Builders
Dành cho người muốn biến ý tưởng thành năng lực / dự án / portfolio

#### Track C — Community Leaders
Dành cho người có tiềm năng trở thành mentor / chapter builder / facilitator

#### Track D — Sponsored Seats
Dành cho người được donor / partner / scholarship support

---

## VI. CÁCH DSTS GẮN VỚI NGUOIVIET.MUONNOI.ORG

### 6.1. Vai trò trong umbrella

DSTS phải được hiển thị trên `nguoiviet.muonnoi.org` như:

- flagship program đầu tiên
- minh chứng cho cách tổ chức làm việc
- nơi donor / mentor / volunteer dễ nhìn thấy tác động
- nơi chapter hoặc địa phương có thể replicate sau

### 6.2. Link flow đúng

`nguoiviet.muonnoi.org`  
→ xem mission  
→ xem programs  
→ chọn DSTS  
→ sang `duongsaotoasang.com`  
→ apply / nominate / sponsor / mentor

### 6.3. Flow ngược

`duongsaotoasang.com`  
→ participant hoàn thành  
→ được giới thiệu sang umbrella network  
→ vào community, mentorship, learning, workforce hoặc chapter lanes khác

---

## VII. DSTS VÀ DONOR / PARTNER SUPPORT

### 7.1. Lane phù hợp

DSTS rất hợp với 4 loại support:

1. **Sponsor a seat**  
   tài trợ một suất tham gia

2. **Sponsor a cohort**  
   tài trợ một cohort / nhóm

3. **Mentor support**  
   chuyên gia đồng hành

4. **Program partnership**  
   doanh nghiệp / trường / địa phương đồng triển khai

### 7.2. Không public ở lớp đầu

Không nên public:

- ROI
- equity
- cap table
- “đầu tư để nhận lại”
- grant pha với investment

---

## VIII. SITE STRUCTURE KHUYẾN NGHỊ CHO DSTS

### 8.1. Public routes

| Route | Mục đích |
|------|---------|
| `/` | Hero + program overview |
| `/hanh-trinh` | Journey / track / milestones |
| `/tham-gia` | Ai phù hợp / ai không phù hợp / apply |
| `/mentor` | Mentor lane |
| `/tai-tro-mot-suat` | Sponsor a seat / sponsor a cohort |
| `/cau-chuyen` | Stories / case studies |
| `/faq` | Câu hỏi thường gặp |
| `/legal` | Program disclosures / consent / policies |

### 8.2. Không bắt buộc giai đoạn đầu

- app phức tạp
- dashboard participant quá lớn
- marketplace
- social feed
- gamification nặng

---

## IX. NGÔN NGỮ PHẢI KHÓA

### Dùng được

- hành trình
- đồng hành
- mentor
- cohort
- chương trình trọng điểm
- tài trợ một suất
- chương trình dành cho người cần định hướng / phát triển / thực hành
- câu chuyện tiến bộ thật
- cộng đồng đồng hành dài hạn

### Không dùng

- đảm bảo thành công
- đổi đời
- bảo đảm việc làm
- đầu tư vào con người để sinh lời
- nhận cổ phần chương trình
- quỹ đầu tư chương trình

---

## X. DELIVERABLES DSTS PHẢI CÓ

1. Program one-pager
2. Program FAQ
3. Apply form
4. Nomination form
5. Sponsor-a-seat form
6. Mentor interest form
7. Story permission policy
8. Basic impact reporting format

---

## XI. PHÁN QUYẾT ÁP DỤNG

### Dùng được ngay

- DSTS là flagship program
- journey-based positioning
- donor / mentor / partner lanes
- public structure cho dev build
- DSTS as proof engine cho umbrella mission

### Chưa được claim

- measurable outcomes phóng đại nếu chưa có proof
- scale toàn cầu nếu chưa có chapters thật
- chứng nhận/chuyển đổi nghề nghiệp nếu chưa có hệ đó thật

---

## XII. KẾT LUẬN

DSTS phải được xây như **program architecture**, không phải chỉ là một trang kể chuyện.

**Câu chốt:**  
Nếu `nguoiviet.muonnoi.org` là “định chế cộng đồng đang hình thành”, thì `duongsaotoasang.com` phải là “chương trình chủ lực đầu tiên chứng minh định chế đó làm được việc thật”.
