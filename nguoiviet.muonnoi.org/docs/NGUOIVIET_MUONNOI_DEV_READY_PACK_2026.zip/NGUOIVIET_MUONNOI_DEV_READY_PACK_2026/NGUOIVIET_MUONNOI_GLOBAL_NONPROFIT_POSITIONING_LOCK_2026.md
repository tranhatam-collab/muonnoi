# NGUOIVIET_MUONNOI_GLOBAL_NONPROFIT_POSITIONING_LOCK_2026

**Ngày:** 2026-06-12  
**Trạng thái:** Founder Review Draft  
**Phạm vi:** `nguoiviet.muonnoi.org`, `duongsaotoasang.com`, các chương trình cộng đồng liên quan  
**Mục đích:** Khóa posture chiến lược, thương hiệu, pháp lý và public narrative cho định hướng “Người Việt Muôn Nơi” theo hướng tổ chức cộng đồng toàn cầu / public-benefit initiative.

---

## I. PHÁN QUYẾT CHIẾN LƯỢC

### 1.1. Kết luận

`nguoiviet.muonnoi.org` **không nên** được định vị như:

- một website cộng đồng đơn lẻ
- một mạng xã hội người Việt chung chung
- một landing page giới thiệu hội nhóm
- một “quỹ đầu tư” hay “quỹ cộng đồng” public

`nguoiviet.muonnoi.org` **nên** được định vị như:

> **Global Vietnamese Community Initiative**  
> Một sáng kiến cộng đồng toàn cầu dành cho người Việt và bạn bè của cộng đồng Việt, kết nối học tập, công nghệ, cơ hội nghề nghiệp, chương trình xã hội, và các hành trình đồng hành dài hạn.

### 1.2. Câu khóa public

Dùng được:

- Sáng kiến cộng đồng Người Việt toàn cầu
- Global Vietnamese Community Initiative
- Community platform for learning, opportunity, technology, and contribution
- Nền tảng kết nối người Việt muôn nơi để học tập, cộng tác và tạo cơ hội

Không dùng ở giai đoạn hiện tại:

- Quỹ toàn cầu
- Global nonprofit foundation
- Tổ chức phi lợi nhuận quốc tế đã hoàn chỉnh
- Quỹ đầu tư cộng đồng
- Public charity đã được công nhận

### 1.3. Lý do

Hướng “global nonprofit / public-benefit” là đúng về chiến lược dài hạn, nhưng public posture hiện tại phải đi theo nguyên tắc:

1. **Build real first**
2. **Governance before claims**
3. **Programs before institution-sized words**
4. **Legal review before official nonprofit claims**

---

## II. ĐÃ XÁC MINH / CHƯA XÁC MINH

### 2.1. Đã xác minh

Theo IRS, một tổ chức muốn được miễn thuế theo **501(c)(3)** phải được tổ chức và vận hành vì các mục đích được miễn trừ như từ thiện, giáo dục, khoa học..., không được để thu nhập ròng phục vụ lợi ích cá nhân, và bị hạn chế về vận động hành lang / hoạt động chính trị.  
Nguồn nền tảng: IRS 501(c)(3), Application for recognition of exemption, Required provisions for organizing documents.

Theo IRS, nếu không đáp ứng ngoại lệ của Section 509(a), tổ chức 501(c)(3) mặc định sẽ bị xem là **private foundation**; để đi theo hướng **public charity** cần cấu trúc và nguồn hỗ trợ công chúng phù hợp.

Tại Việt Nam, nếu sau này vận hành như một **foreign NGO** hoặc có thực thể phi chính phủ nước ngoài hoạt động tại Việt Nam, cần rà soát khung quản lý tương ứng theo **Nghị định 58/2022/NĐ-CP** và các văn bản áp dụng liên quan.

### 2.2. Chưa xác minh

Trong tài liệu này **chưa xác minh**:

- pháp nhân nào hiện tại của Founder phù hợp nhất để làm hạt nhân nonprofit / public-benefit
- cấu trúc tối ưu giữa Việt Nam / Mỹ / Canada / entity mới
- quy trình đăng ký gây quỹ / charitable solicitation tại các bang/quốc gia mục tiêu
- khả năng sử dụng ngay tên “tổ chức phi lợi nhuận toàn cầu” trên public pages
- quy chế thuế, accounting, donor receipting, grant compliance cho cấu trúc cuối cùng

### 2.3. Hệ quả vận hành

Tài liệu này phải được hiểu là:

- **khóa posture chiến lược**
- **khóa public language**
- **khóa kiến trúc triển khai**
- **không phải ý kiến pháp lý cuối**

---

## III. VAI TRÒ CỦA NGUOIVIET.MUONNOI.ORG

### 3.1. Vai trò đúng

`nguoiviet.muonnoi.org` là **umbrella platform** cho:

- sứ mệnh cộng đồng toàn cầu
- chương trình cộng đồng
- chapters / hubs
- volunteer / mentor / partner / donor lanes
- stories / reports / impact
- public trust surface
- governance and disclosure layer

### 3.2. Không được làm

- Không biến thành trang tuyển thành viên mơ hồ không có cấu trúc
- Không biến thành “mạng xã hội” thiếu governance
- Không biến thành portal kêu gọi đầu tư công khai
- Không trộn lane cộng đồng / donor / volunteer với lane đầu tư / strategic capital
- Không public overclaim về legal status

### 3.3. Vai trò dài hạn

Nếu đi đúng, `nguoiviet.muonnoi.org` có thể phát triển thành:

- public-benefit platform
- global Vietnamese opportunity network
- operating hub cho các chương trình flagship
- nơi kết nối người Việt trong nước, diaspora, mentor, doanh nghiệp, đối tác giáo dục, và các chương trình vì cộng đồng

---

## IV. TƯ THẾ THƯƠNG HIỆU

### 4.1. Brand hierarchy

| Tầng | Vai trò | Domain |
|-----------|---------|--------|
| Umbrella mission | Tổ chức / initiative / network | `nguoiviet.muonnoi.org` |
| Flagship program | Chương trình trọng điểm kể chuyện và tạo impact | `duongsaotoasang.com` |
| Program surfaces khác | Việc làm, học tập, nhà chung, AI, v.v. | các subdomain / program pages liên quan |

### 4.2. Tone of voice

Bắt buộc:

- điềm tĩnh
- chính xác
- không hô khẩu hiệu rỗng
- có lý do tồn tại
- có cấu trúc tổ chức
- có kỷ luật pháp lý
- có năng lực triển khai thật

Không dùng:

- “thay đổi thế giới” kiểu rỗng
- “cộng đồng số 1”
- “quỹ toàn cầu”
- “hệ sinh thái lớn nhất”
- “giải quyết toàn bộ vấn đề người Việt”

### 4.3. Mệnh đề giá trị public

Gợi ý mệnh đề khóa:

> Người Việt Muôn Nơi là một sáng kiến cộng đồng toàn cầu nhằm kết nối người Việt và bạn bè của cộng đồng Việt với cơ hội học tập, công nghệ, việc làm, chương trình xã hội, và các hành trình đồng hành dài hạn.

---

## V. PHASE LEGAL-SAFE

### Phase A — Initiative posture (nên dùng ngay)

Public wording:

- initiative
- community platform
- public-benefit direction
- educational and opportunity programs
- donor / volunteer / partner support

### Phase B — Nonprofit in formation (chỉ sau legal review)

Public wording:

- nonprofit initiative in formation
- public-benefit organization in formation
- charitable / educational direction under review

### Phase C — Recognized nonprofit / public charity (chỉ sau khi có giấy tờ thật)

Public wording:

- nonprofit organization
- public charity
- charitable organization
- grantmaking / scholarship body (nếu đúng thật)

---

## VI. 6 NGUYÊN TẮC BẮT BUỘC

1. **Programs first** — phải có chương trình chạy thật trước khi public lớn.
2. **Governance before fundraising claims** — phải có governance page và legal-safe disclosures.
3. **No public securities posture** — không trộn với investment portal.
4. **No fake institution language** — không tự gọi mình là nonprofit toàn cầu hoàn chỉnh khi chưa legal-ready.
5. **Impact reporting required** — mọi lời kêu gọi donor/partner phải đi kèm reporting logic.
6. **Two-entity thinking** — về dài hạn nên tách nonprofit/public-benefit lane khỏi commercial lane.

---

## VII. CHỈ DẪN CHO TEAM CONTENT

### 7.1. Nên dùng

- sáng kiến
- cộng đồng
- đồng hành
- tài trợ chương trình
- tài trợ suất học
- mentor
- volunteer
- chapter
- partner
- báo cáo tác động
- câu chuyện thật
- chương trình trọng điểm

### 7.2. Không nên dùng

- đầu tư ngay
- quỹ toàn cầu
- mua cổ phần
- quỹ phi lợi nhuận đã được cấp phép
- donor sẽ nhận lợi nhuận
- vốn cộng đồng sinh lời

---

## VIII. PHÁN QUYẾT ÁP DỤNG

### Dùng được ngay

- public posture của `nguoiviet.muonnoi.org`
- brand hierarchy với DSTS
- governance direction
- donor / partner / volunteer architecture
- dev handoff để build site structure

### Chưa được claim công khai

- legal nonprofit status cuối cùng
- public charity / 501(c)(3) / foreign NGO đã có
- tax-deductible donation
- regulated donor receipting / grant eligibility
- global nonprofit recognition

---

## IX. DISCLOSURE BẮT BUỘC

> Tài liệu này là khóa định vị chiến lược và vận hành nội bộ để xây dựng public posture cho sáng kiến cộng đồng Người Việt Muôn Nơi. Tài liệu này không phải ý kiến pháp lý, thuế hoặc kế toán, và không xác nhận rằng cấu trúc nonprofit / public-benefit đã hoàn tất về mặt pháp lý tại bất kỳ quốc gia nào.

---

## X. KẾT LUẬN

`nguoiviet.muonnoi.org` phải được xây như một **umbrella community institution in formation**:

- đủ nghiêm túc để mang dáng tổ chức
- đủ sạch để không overclaim
- đủ rõ để các chương trình gắn vào
- đủ an toàn để public
- đủ linh hoạt để legal structure hoàn thiện dần

**Câu chốt:**  
Không xây như một website cộng đồng.  
Xây như phần public đầu tiên của một định chế cộng đồng đang được hình thành, với chương trình thật, governance thật, lane thật, và impact reporting thật.
