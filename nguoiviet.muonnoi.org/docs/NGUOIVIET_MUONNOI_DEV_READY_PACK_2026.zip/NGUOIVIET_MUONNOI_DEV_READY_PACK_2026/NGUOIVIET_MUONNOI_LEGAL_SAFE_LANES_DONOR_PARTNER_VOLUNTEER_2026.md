# NGUOIVIET_MUONNOI_LEGAL_SAFE_LANES_DONOR_PARTNER_VOLUNTEER_2026

**Ngày:** 2026-06-12  
**Trạng thái:** Founder Review Draft  
**Phạm vi:** `nguoiviet.muonnoi.org`, `duongsaotoasang.com`, các public pages và forms liên quan  
**Mục đích:** Khóa các lane công khai hợp pháp và an toàn hơn cho donor / partner / volunteer / mentor.

---

## I. PHÁN QUYẾT CHÍNH

`nguoiviet.muonnoi.org` và `duongsaotoasang.com` **được phép public mạnh** theo các lane sau:

1. **Donor / Sponsor Support**
2. **Partner / Co-development**
3. **Volunteer / Mentor**
4. **Program Participation / Nomination**
5. **Request Private Discussion**

Các site này **không được** public theo lane:

- public securities offer
- community investment with return expectation
- equity solicitation
- ROI-based invite
- “góp vốn nhận lợi nhuận”

---

## II. LANE A — DONOR / SPONSOR SUPPORT

### 2.1. Dùng cho

- tài trợ chương trình
- tài trợ một suất tham gia
- tài trợ một cohort
- học bổng / scholarship support
- tài trợ mentor time / operational support
- tài trợ nội dung / công nghệ phục vụ cộng đồng

### 2.2. Ngôn ngữ đúng

- tài trợ
- sponsor a seat
- sponsor a cohort
- scholarship support
- community support
- donor support
- philanthropic support

### 2.3. Không dùng

- góp vốn
- đầu tư
- lợi nhuận
- chia lãi
- hoàn vốn
- equity

### 2.4. Public promise đúng

Có thể hứa:

- cập nhật tiến độ
- báo cáo sử dụng hỗ trợ
- impact summary
- acknowledgement / donor recognition nếu phù hợp

Không hứa:

- bất kỳ lợi ích tài chính cố định nào
- quyền sở hữu
- quyền nhận cổ phần
- lợi tức

---

## III. LANE B — PARTNER / CO-DEVELOPMENT

### 3.1. Dùng cho

- doanh nghiệp đồng triển khai
- trường học / tổ chức giáo dục
- địa phương / chapter host
- đối tác công nghệ
- đối tác truyền thông
- co-development cho chương trình hoặc hạ tầng

### 3.2. Public wording đúng

- đề xuất hợp tác
- partnership
- co-development
- implementation partner
- education partner
- community partner
- local chapter support

### 3.3. Không dùng

- suất đầu tư
- deal đầu tư
- terms đầu tư public
- mua phần trăm chương trình

---

## IV. LANE C — VOLUNTEER / MENTOR

### 4.1. Dùng cho

- mentor
- volunteer
- facilitator
- speaker
- reviewer
- chapter builder
- host / coordinator

### 4.2. Public wording đúng

- trở thành mentor
- đồng hành tình nguyện
- volunteer with the program
- góp chuyên môn
- chapter builder interest

### 4.3. Không được tạo nhầm

- không được để mentor form giống recruiting paid role nếu chưa có role thật
- không được để volunteer form giống hợp đồng lao động
- không hứa “thu nhập chắc chắn” nếu chỉ là volunteer lane

---

## V. LANE D — PROGRAM PARTICIPATION / NOMINATION

### 5.1. Dùng cho

- người muốn tham gia
- người muốn được giới thiệu / nominate
- nhóm muốn tham gia cùng
- gia đình / chapter / trường muốn gửi người vào chương trình

### 5.2. Public wording đúng

- đăng ký tham gia
- đề cử một người tham gia
- apply
- nominate
- yêu cầu trao đổi về chương trình

### 5.3. Không được

- dùng ngôn ngữ “đóng tiền để đảm bảo được nhận”
- hứa chắc chắn được vào
- hứa chuyển đổi nghề nghiệp chắc chắn
- hứa kết quả cuộc đời

---

## VI. LANE E — REQUEST PRIVATE DISCUSSION

### 6.1. Dùng cho

- strategic donor
- senior partner
- chapter launch
- sensitive collaboration
- media / foundation / institution inquiry

### 6.2. Ngôn ngữ đúng

- yêu cầu trao đổi riêng
- request private discussion
- private overview request

### 6.3. Không dùng để làm gì

- không dùng như cánh cửa public cho strategic capital / investment solicitation
- không dùng để public term sheet / valuation / equity

---

## VII. CTA KHÓA CỨNG

### Được dùng

- Đồng hành cùng sáng kiến
- Tài trợ một suất học
- Tài trợ một chương trình
- Trở thành đối tác
- Trở thành mentor
- Tham gia chương trình
- Đề cử một người tham gia
- Yêu cầu trao đổi riêng

### Không được dùng

- Đầu tư ngay
- Góp vốn ngay
- Mua cổ phần
- Nhận lợi nhuận
- Nhận ROI
- Đặt suất đầu tư
- Chuyển khoản đầu tư

---

## VIII. FORM POLICY

## 8.1. Lane selector bắt buộc

Mọi form public phải bắt buộc có trường:

**Bạn đang quan tâm theo hướng nào?**

- Tôi muốn tham gia chương trình
- Tôi muốn tài trợ / sponsor
- Tôi muốn làm mentor / volunteer
- Tôi muốn hợp tác triển khai
- Tôi muốn mở chapter / hub
- Tôi muốn trao đổi riêng

## 8.2. Không hỏi công khai

- số tiền đầu tư kỳ vọng
- kỳ vọng lợi nhuận
- số cổ phần mong muốn
- cap table related questions
- payment instruction public

## 8.3. Legal acknowledgement bắt buộc

Ví dụ:

> Tôi hiểu rằng nội dung trên website này nhằm giới thiệu chương trình, sáng kiến cộng đồng, các hình thức đồng hành, tài trợ, hợp tác và tình nguyện. Nội dung này không phải lời mời chào bán chứng khoán, không phải lời mời đầu tư đại chúng, và không bảo đảm bất kỳ lợi ích tài chính nào.

---

## IX. DISCLOSURE / FOOTER BẮT BUỘC

Footer nên có một đoạn tương đương:

> Nội dung trên website này chỉ nhằm giới thiệu sáng kiến cộng đồng, chương trình, cơ hội đồng hành, tài trợ, hợp tác và tình nguyện. Nội dung này không cấu thành lời mời chào bán chứng khoán, không phải tư vấn đầu tư, pháp lý, thuế hoặc kế toán, và không bảo đảm bất kỳ khoản lợi nhuận hay quyền sở hữu nào. Mọi trao đổi nhạy cảm hoặc hợp tác riêng chỉ được thực hiện sau quá trình review phù hợp.

---

## X. DONOR / PARTNER / VOLUNTEER DATA POLICY TỐI THIỂU

### 10.1. Public pages không hiển thị

- bank account details
- QR thanh toán công khai
- sensitive legal docs
- internal budget sheets chi tiết nếu chưa duyệt
- personal data của participant chưa có consent

### 10.2. Public pages có thể hiển thị

- mission
- programs
- sponsor types
- mentor interest
- partner pathways
- high-level impact model
- approved stories
- contact routes

---

## XI. RANH GIỚI VỚI INVESTMENT LANE

Nếu sau này có bất kỳ lane nào gần với:

- strategic capital
- private review
- entity-level support with rights
- asset-linked participation

thì lane đó **phải nằm ngoài** public donor/partner/volunteer site structure, và đi qua review riêng.

`nguoiviet.muonnoi.org` public layer không được trở thành:
- investment portal
- equity gateway
- fundraising engine for securities-like products

---

## XII. DEV CHECKLIST

### P0 blockers

- Có CTA kiểu “đầu tư ngay”
- Có bank account / QR public
- Có copy mập mờ giữa tài trợ và đầu tư
- Không có legal acknowledgement trên form
- Không có footer disclosure
- Story pages không có consent-safe flow

### P1 majors

- Lane selector thiếu hoặc không rõ
- Partner page copy còn mang màu “deal đầu tư”
- Volunteer page giống tuyển dụng thương mại
- Donor page hứa hẹn quá mức về tác động

### P2 minors

- CTA wording chưa tối ưu
- FAQ chưa đủ
- Story categorization chưa rõ
- Partner logos chưa có approval logic

---

## XIII. KẾT LUẬN

Muốn `nguoiviet.muonnoi.org` và `duongsaotoasang.com` public an toàn và đẳng cấp, phải khóa rất cứng:

- donor lane là donor lane
- partner lane là partner lane
- volunteer lane là volunteer lane
- program apply là program apply
- mọi thứ không được pha màu “đầu tư sinh lợi”

**Câu chốt:**  
Public tốt nhất là nói đúng mission, đúng lane, đúng quyền và đúng giới hạn. Không nhập nhằng thì trust tăng, legal risk giảm, và về sau scale lên thành tổ chức cộng đồng toàn cầu mới bền.
